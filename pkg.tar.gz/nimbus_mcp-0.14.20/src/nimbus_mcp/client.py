"""Thin HTTP client for the Nimbus backend (X-MCP-Key locally, Bearer when hosted)."""

from __future__ import annotations

import hashlib
from contextlib import AbstractContextManager, nullcontext
from pathlib import Path
from typing import Any

import httpx

from .config import McpConfig, load_config
from .errors import McpToolError
from .setup_mode import (
    SetupRequired,
    desktop_app_not_running_guidance,
    local_mode_guidance,
    setup_guidance,
    token_rejected_guidance,
)

__all__ = ["McpToolError", "NimbusClient", "NullClient"]

_BACKEND_DOWN_HINT = (
    "Cannot reach the Nimbus backend at {url}. "
    "Start the desktop app (or the dev backend on :8080) and retry."
)
_HOSTED_DOWN_HINT = (
    "Cannot reach hosted Nimbus at {url}. Check network connectivity and "
    "NIMBUS_API_URL, then retry."
)
_TIMEOUT_HINT_LOCAL = (
    "Timed out talking to the Nimbus backend at {url}. Is the desktop/dev "
    "backend running and not stuck on a heavy job?"
)
_TIMEOUT_HINT_HOSTED = (
    "Timed out talking to hosted Nimbus at {url} (request limit {timeout}s). "
    "Heavy calls like foundation.compare embed every backbone — retry, or "
    "narrow the data (fewer trials / one subject)."
)
_AUTH_HINT = (
    "Nimbus rejected the MCP key ({status}). Check that MCP_LOCAL_KEY on the backend "
    "matches NIMBUS_MCP_KEY for this server, and that the backend runs locally "
    "(desktop app or DEBUG=1) — the key is never accepted on Fly deployments."
)

# Quota denials (run_pipeline / run_experiment 403s) that carry the pricing
# deep-link; the single place the link is appended is _backend_error (v0.5 T5).
# The values are the backend's dotted wire codes (utils/api_codes.py:
# FREEMIUM_MONTHLY_QUOTA_EXCEEDED / RUNTIME_PAID_TIER_REQUIRED constants).
_QUOTA_ERROR_CODES = frozenset(
    {"nimbus.freemium.monthly_quota_exceeded", "nimbus.runtime.paid_tier_required"}
)
QUOTA_PRICING_URL = "https://studio.nimbusbci.com/pricing?reason=mcp-quota"

_SECRET_PREFIX_LEN = 12


def _mask_secret(secret: str) -> str:
    """``nimb_abcdef…`` — a 12-char prefix so a printed secret stays
    identifiable but never reconstructable. A secret within the prefix window
    would be printed WHOLE by a naive slice — those get a 4-char prefix
    instead. Shared by the CLI status doctor and ``credential_report()``."""
    prefix_len = _SECRET_PREFIX_LEN if len(secret) > _SECRET_PREFIX_LEN else 4
    return f"{secret[:prefix_len]}…"


def _credential_fingerprint(secret: str) -> str:
    """sha256 hex[:16] of a token/key — an opaque, stable-per-credential scope
    key for process-local state (campaign's experiment registry), so one
    shared gateway's users cannot see each other's state. Never displayed:
    unreversible, but it exists to be compared, not shown."""
    return hashlib.sha256(secret.encode("utf-8")).hexdigest()[:16]


class NimbusClient:
    """Blocking HTTP client; tools run in FastMCP's worker threads.

    Auth mode follows the config: a ``nimbus_token`` (env token, token file,
    or the login store) sends ``Authorization: Bearer <token>`` (hosted
    backend, no X-MCP-Key header); otherwise the local ``mcp_key`` — the env
    key, the key file, or the desktop-app auto-discovered key — is sent as
    ``X-MCP-Key`` (the desktop key is local, so the header mode is right).
    """

    def __init__(self, config: McpConfig, transport: httpx.BaseTransport | None = None) -> None:
        if config.nimbus_token:
            headers = {"Authorization": f"Bearer {config.nimbus_token}"}
            self._token_mode = True
            self.access_mode = "hosted"
        elif config.mcp_key:
            headers = {"X-MCP-Key": config.mcp_key}
            self._token_mode = False
            self.access_mode = "local"
        else:
            # Local Free tier (plan X9): no credential is NOT an error. The
            # client talks to the local backend (desktop app / dev backend)
            # anonymously; cloud-only tools answer with a structured login
            # prompt at the moment they need an account (access.py).
            headers = {}
            self._token_mode = False
            self.access_mode = "anonymous"
        self.config = config
        headers["X-Nimbus-Client"] = f"nimbus-mcp/{_mcp_version()}"
        self._http = httpx.Client(
            base_url=config.api_url,
            headers=headers,
            timeout=300.0,
            transport=transport,
        )

    def close(self) -> None:
        self._http.close()

    def bound_client(self) -> AbstractContextManager[NimbusClient]:
        """A client safe to use outside the MCP request context, as a context
        manager the caller owns for its lifetime (e.g. campaign's worker
        thread, where fastmcp's header lookup answers {} and request-scoped
        credential resolution cannot run). A plain NimbusClient is
        context-free: yields itself and never closes on exit — it is the
        process-wide client the server was built with. The hosted wrapper
        yields a fresh per-token client it closes on exit instead."""
        return nullcontext(self)

    def ensure_ready(self) -> None:
        """Preflight hook for tools that do work outside the request path
        (campaign's ``run_experiment`` spawns a worker thread that would
        otherwise swallow a missing credential). Credentialed clients are a
        no-op here — the hosted token check lives in
        :func:`nimbus_mcp.access.verify_hosted_credential`, called only by
        ``experiment.run`` (cached), so polls never pay for it;
        :class:`NullClient` raises :class:`SetupRequired`. Anonymous
        Local Free clients probe the local backend's health endpoint
        (bounded 2 s): unreachable -> the local-mode guidance, so a campaign
        never registers state for a backend that does not exist."""
        if getattr(self, "access_mode", None) != "anonymous":
            return None
        try:
            httpx.get(f"{self.config.api_url}/health", timeout=2.0)
        except httpx.HTTPError:
            raise SetupRequired(local_mode_guidance(None, self.config.api_url)) from None
        return None

    def credential_report(self) -> dict[str, Any]:
        """Identity of the credential this client sends, for display
        (``account.whoami``): where it came from and the masked secret —
        never the raw token/key."""
        secret = self.config.nimbus_token or self.config.mcp_key
        return {
            "source": self.config.credential_meta.get("source") or "env",
            "token": _mask_secret(secret) if secret else None,
        }

    def credential_fingerprint(self) -> str:
        """Stable id of the credential this client authenticates with — the
        scope key for process-local state (see
        :func:`_credential_fingerprint`), so state registered under one
        credential is invisible under another. Anonymous Local Free clients
        (no secret) share the ``"anon"`` scope."""
        secret = self.config.nimbus_token or self.config.mcp_key
        return _credential_fingerprint(secret) if secret else "anon"

    def _auth_rejection(self, status: int) -> McpToolError:
        """The exception for a 401 (see _request).

        Token mode: the token is expired or revoked — guidance with a re-login
        action and the day counts decoded locally (SetupRequired, converted to
        the guidance dict by the server middleware). Key mode: a wrong local
        key, which no login fixes — keep the MCP_LOCAL_KEY mismatch hint.
        """
        if getattr(self, "access_mode", None) == "anonymous":
            # Anonymous local call rejected: the fix is a local identity
            # (desktop app / dev key), NOT a Studio login.
            return SetupRequired(local_mode_guidance(status))
        if self._token_mode:
            return SetupRequired(token_rejected_guidance(self.config.nimbus_token, status))
        return McpToolError(_AUTH_HINT.format(status=status))

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self._request("GET", path, params=params)

    def post(
        self, path: str, json: dict[str, Any] | None = None, *, allow_422: bool = False
    ) -> Any:
        """POST; with ``allow_422`` a 422 body is RETURNED instead of raised.

        Opt-in for endpoints whose 422 is a verdict payload the caller branches
        on (protocol validate: ``{"valid": false, "errors": [...]}``), not an
        error — the generic ProblemDetail 422s of every other route keep
        raising."""
        return self._request("POST", path, json=json, allow_422=allow_422)

    def put(self, path: str, json: dict[str, Any] | None = None) -> Any:
        """PUT that tolerates 409 conflicts: returns a conflict payload instead
        of raising, so callers can implement optimistic-revision retries."""
        return self._request("PUT", path, json=json, allow_409=True)

    def patch(self, path: str, json: dict[str, Any] | None = None) -> Any:
        """PATCH; >=400 raises."""
        return self._request("PATCH", path, json=json)

    def delete(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """DELETE; >=400 raises like every other verb (404 = already gone)."""
        return self._request("DELETE", path, params=params)

    def get_bytes(self, path: str) -> bytes:
        return self._request("GET", path, content=True)

    def post_bytes(self, path: str, json: dict[str, Any] | None = None) -> bytes:
        return self._request("POST", path, json=json, content=True)

    def _unreachable_error(self, err: BaseException) -> McpToolError:
        """Hosted-aware connectivity / timeout message (#471)."""
        if getattr(self, "access_mode", None) == "anonymous":
            # No local backend to talk to and no local identity: the local
            # onboarding guidance (desktop app / dev key) is the actionable
            # answer — a raw connect error would dead-end Local Free users.
            return SetupRequired(local_mode_guidance(None, self.config.api_url))
        url = self.config.api_url
        if (
            not self._token_mode
            and self.config.credential_meta.get("source") == "desktop"
            and not isinstance(err, httpx.TimeoutException)
        ):
            # Auto-discovered desktop key but nothing answers: the app is
            # closed (or gone). Same onboarding payload, desktop-first lead.
            return SetupRequired(desktop_app_not_running_guidance(url))
        timeout = getattr(self._http.timeout, "read", None) or getattr(
            self._http.timeout, "timeout", 300.0
        )
        if isinstance(err, httpx.TimeoutException):
            if self._token_mode:
                return McpToolError(_TIMEOUT_HINT_HOSTED.format(url=url, timeout=timeout))
            return McpToolError(_TIMEOUT_HINT_LOCAL.format(url=url))
        if self._token_mode:
            return McpToolError(_HOSTED_DOWN_HINT.format(url=url))
        return McpToolError(_BACKEND_DOWN_HINT.format(url=url))

    def post_file(self, path: str, file_path: Path, fields: dict[str, str] | None = None) -> Any:
        """POST a multipart/form-data request with one ``file`` part plus text fields."""
        data_fields = dict(fields or {})
        try:
            with open(file_path, "rb") as fh:
                resp = self._http.post(path, data=data_fields, files={"file": fh})
        except httpx.HTTPError as err:
            raise self._unreachable_error(err) from err
        if resp.status_code == 401:
            raise self._auth_rejection(resp.status_code)
        if resp.status_code >= 400:
            raise self._backend_error(resp)
        return self._json(resp)

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        content: bool = False,
        allow_409: bool = False,
        allow_422: bool = False,
    ) -> Any:
        try:
            resp = self._http.request(method, path, params=params, json=json)
        except httpx.HTTPError as err:
            raise self._unreachable_error(err) from err
        # 401 = the credential was rejected by the auth layer (stale API token in
        # hosted mode, wrong key locally). 403 is a policy denial (e.g. freemium
        # limits) — let it fall through to the generic path so the backend's
        # detail message surfaces (with the pricing link for quota codes).
        if resp.status_code == 401:
            raise self._auth_rejection(resp.status_code)
        # 409 with allow_409 (PUT doc saves): an optimistic-revision conflict,
        # not a hard failure — hand it back so the caller can re-read the
        # revision and retry. Other >=400 statuses still raise below.
        if resp.status_code == 409 and allow_409:
            body = self._json(resp)
            # The backend's 409 is a flat RFC7807 problem body: top-level
            # ``code`` and a string ``detail`` (see backend errors.py
            # user_facing_problem_content). A nested detail.code is only a
            # fallback for non-problem payloads.
            code = body.get("code") if isinstance(body, dict) else None
            if not code and isinstance(body, dict) and isinstance(body.get("detail"), dict):
                code = body["detail"].get("code")
            return {"ok": False, "code": code or "conflict", "status": 409}
        # 422 with allow_422 (protocol validate): the body IS the verdict the
        # tool returns to the agent ({"valid": false, "errors": [...]}) —
        # raising would bury it in a message string.
        if resp.status_code == 422 and allow_422:
            return self._json(resp)
        if resp.status_code >= 400:
            raise self._backend_error(resp)
        return resp.content if content else self._json(resp)

    @staticmethod
    def _json(resp: httpx.Response) -> Any:
        try:
            return resp.json()
        except ValueError:
            return {"ok": False, "raw": resp.text[:500]}

    @staticmethod
    def _backend_error(resp: httpx.Response) -> McpToolError:
        """The exception for a >=400 backend response.

        The message is the human-readable line the agent sees; the HTTP
        ``status_code`` and the backend's stable dotted ``code`` (top-level
        RFC7807 key, nested ``detail.code`` fallback) ride along as
        attributes so tools can branch on them (e.g. inspect_file's
        hosted-backend guidance) without parsing message text.
        """
        body: Any = None
        try:
            body = resp.json()
        except ValueError:
            pass
        detail = body.get("detail") if isinstance(body, dict) else None
        if isinstance(detail, dict):
            msg = detail.get("detail") or detail.get("title") or str(detail)
        else:
            msg = str(detail) if detail else resp.text[:300]
        code = body.get("code") if isinstance(body, dict) else None
        if not code and isinstance(detail, dict):
            code = detail.get("code")
        # Quota denials (the two codes the backend returns from run_pipeline /
        # run_experiment) get the pricing deep-link appended — THIS is the single
        # place the link is added (v0.5 Task 5), so every tool benefits.
        if code in _QUOTA_ERROR_CODES:
            msg = f"{msg} Upgrade or manage your plan: {QUOTA_PRICING_URL}"
        cid = body.get("correlationId") if isinstance(body, dict) else None
        if not (isinstance(cid, str) and cid.strip()):
            cid = resp.headers.get("X-Correlation-ID")
        cid = cid.strip() if isinstance(cid, str) and cid.strip() else None
        code = code if isinstance(code, str) and code else None
        # Surface the stable backend code in the agent-visible text too (the
        # tool error payload is only this message), next to the correlationId.
        retry_after = _retry_after_seconds(body, resp.headers.get("Retry-After"))
        refs = [f"code: {code}"] if code else []
        if retry_after is not None:
            refs.append(f"retryAfter: {retry_after}s")
        if cid:
            refs.append(f"correlationId: {cid}")
        if refs:
            msg = f"{msg} ({', '.join(refs)})"
        return McpToolError(
            f"Nimbus API error {resp.status_code}: {msg}",
            status_code=resp.status_code,
            code=code,
            correlation_id=cid,
            retry_after=retry_after,
        )


def _retry_after_seconds(body: Any, header: str | None) -> int | None:
    """Integer seconds from the body ``retryAfter`` or the ``Retry-After`` header."""
    raw = body.get("retryAfter") if isinstance(body, dict) else None
    for value in (raw, header):
        try:
            seconds = int(str(value).strip())
        except (TypeError, ValueError):
            continue
        if seconds > 0:
            return seconds
    return None


class NullClient:
    """Setup-mode stand-in for :class:`NimbusClient` (no credential resolved).

    Every request method raises :class:`~nimbus_mcp.setup_mode.SetupRequired`
    carrying the guidance payload; ``SetupGuidanceMiddleware`` (server.py)
    converts that into the structured setup dict, so the server starts,
    lists every tool, and each call answers with onboarding guidance instead
    of crashing. ``config`` is a real :class:`McpConfig` so tool code that
    reads ``client.config.export_dir`` (artifacts tools) keeps working.
    """

    def __init__(
        self,
        config: McpConfig | None = None,
        guidance: dict[str, Any] | None = None,
    ) -> None:
        self.config = load_config() if config is None else config
        self._guidance = guidance if guidance is not None else setup_guidance()

    def _setup_required(self) -> SetupRequired:
        return SetupRequired(self._guidance)

    def credential_report(self) -> dict[str, Any]:
        """Setup-mode counterpart of :meth:`NimbusClient.credential_report`:
        no credential was resolved, so there is nothing to identify."""
        return {"source": None, "token": None}

    def credential_fingerprint(self) -> str:
        """Setup-mode counterpart of
        :meth:`NimbusClient.credential_fingerprint`: no credential resolved,
        so the anonymous scope. Campaign tools never reach it — their
        ``ensure_ready()`` preflight raises the setup guidance first."""
        return "anon"

    def ensure_ready(self) -> None:
        """Preflight counterpart of :meth:`NimbusClient.ensure_ready`: no
        credential resolved, so raise — the caller fails fast with the
        guidance payload instead of dead-ending in a background thread."""
        raise self._setup_required()

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        raise self._setup_required()

    def post(
        self, path: str, json: dict[str, Any] | None = None, *, allow_422: bool = False
    ) -> Any:
        """Match :meth:`NimbusClient.post`, including ``allow_422``.

        Setup mode must raise :class:`SetupRequired`, not ``TypeError``, when
        a tool (``protocol.validate``) passes the flag.
        """
        del allow_422  # signature parity only; there is no request to send
        raise self._setup_required()

    def put(self, path: str, json: dict[str, Any] | None = None) -> Any:
        raise self._setup_required()

    def patch(self, path: str, json: dict[str, Any] | None = None) -> Any:
        raise self._setup_required()

    def delete(self, path: str, params: dict[str, Any] | None = None) -> Any:
        raise self._setup_required()

    def get_bytes(self, path: str) -> bytes:
        raise self._setup_required()

    def post_bytes(self, path: str, json: dict[str, Any] | None = None) -> bytes:
        raise self._setup_required()

    def post_file(
        self,
        path: str,
        file_path: Path,
        fields: dict[str, str] | None = None,
    ) -> Any:
        raise self._setup_required()

    def close(self) -> None:
        pass


def _mcp_version() -> str:
    from . import __version__

    return __version__
