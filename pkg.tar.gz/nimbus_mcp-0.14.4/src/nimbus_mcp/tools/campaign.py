"""Campaign tools: run a batch of pipelines as one paced experiment.

``experiment.run`` validates, spawns a background worker thread and returns
immediately — the tool call never blocks on the worker. The worker submits at
most ``min(max_concurrent, 2)`` runs in flight, submits the next run as each
one reaches a terminal state (polling execution summaries), backs off and
retries on "Execution queue full" (max 3 attempts per run), then aggregates
trimmed metrics over the completed runs.
"""

from __future__ import annotations

import threading
import time
import uuid
from contextlib import AbstractContextManager
from dataclasses import dataclass
from statistics import fmean, pstdev
from typing import Any

from fastmcp import FastMCP

from ..client import McpToolError, NimbusClient
from ..setup_mode import SetupRequired
from ._annotations import MUTATING, READ_ONLY
from ._guards import safe_segment
from .run import _METRIC_KEYS, synth_layout

POLL_INTERVAL_SEC = 5.0
QUEUE_FULL_BACKOFF_SEC = 5.0
MAX_SUBMIT_ATTEMPTS = 3
MAX_POLL_ATTEMPTS = 3
POLL_RETRY_BACKOFF_SEC = 2.0
MAX_RUNS = 25
MAX_IN_FLIGHT = 2
# Registry cap: each state holds up to 25 run rows with the full posted
# train_graph (tens of KB each), so on a long-lived hosted gateway the map
# must evict — oldest TERMINAL experiments go first; a still-running
# experiment is never evicted while it can still be polled to a terminal
# state by its own worker.
MAX_EXPERIMENTS = 64

_AGGREGATE_METRICS = ("accuracyPct", "evalAccuracyPct", "kappa", "itr")
_QUEUE_FULL_MARKER = "Execution queue full"
_TERMINAL = ("completed", "failed", "cancelled")


@dataclass
class RunRow:
    name: str
    train_graph: dict[str, Any]
    execution_id: str | None = None
    status: str = "pending"  # pending | running | completed | failed
    error: str | None = None
    metrics: dict[str, Any] | None = None
    submit_attempts: int = 0  # submissions used (queue-full retries included)


class ExperimentState:
    def __init__(
        self,
        experiment_id: str,
        runs: list[RunRow],
        max_in_flight: int,
        *,
        compute_origin: dict[str, Any] | None = None,
    ) -> None:
        self.experiment_id = experiment_id
        self.runs = runs
        self.max_in_flight = max_in_flight
        self.status = "running"
        self.aggregates: dict[str, Any] | None = None
        self.compute_origin = compute_origin

    def payload(self) -> dict[str, Any]:
        rows: list[dict[str, Any]] = []
        for run in self.runs:
            row: dict[str, Any] = {
                "name": run.name,
                "executionId": run.execution_id,
                "status": run.status,
            }
            if run.error is not None:
                row["error"] = run.error
            if run.metrics is not None:
                row["metrics"] = run.metrics
            rows.append(row)
        out: dict[str, Any] = {
            "experimentId": self.experiment_id,
            "status": self.status,
            "runs": rows,
        }
        if self.aggregates is not None:
            out["aggregates"] = self.aggregates
        if self.compute_origin is not None:
            out["computeOrigin"] = self.compute_origin
        return out


class Experiments:
    """Thread-safe process-local registry of experiment states.

    Entries are keyed by ``"<credential fingerprint>:<experiment_id>"``: the
    registry lives in one process, and a hosted gateway authenticates many
    users per process — keying by the bare id would let any authenticated
    gateway user read another user's experiment snapshot by id. The scoping
    is internal: experiment.run still returns the plain experiment_id, and
    experiment.get recomputes the caller's key from its own credential."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self._states: dict[str, ExperimentState] = {}

    @staticmethod
    def key(fingerprint: str, experiment_id: str) -> str:
        return f"{fingerprint}:{experiment_id}"

    def add(self, state: ExperimentState, fingerprint: str) -> None:
        with self.lock:
            self._states[self.key(fingerprint, state.experiment_id)] = state
            self._evict_locked()

    def _evict_locked(self) -> None:
        """Drop the oldest terminal experiments while over MAX_EXPERIMENTS
        (insertion order = registration order). A terminal state can only be
        re-read via experiment.get — pollers hold the id and learn the result
        before their experiment leaves the running workers' hands; the cap is
        generous (64), so eviction only bites a long-lived gateway process.
        Called with the lock held."""
        if len(self._states) <= MAX_EXPERIMENTS:
            return
        for key, state in list(self._states.items()):
            if len(self._states) <= MAX_EXPERIMENTS:
                break
            if state.status in _TERMINAL:
                del self._states[key]

    def snapshot(self, fingerprint: str, experiment_id: str) -> dict[str, Any] | None:
        with self.lock:
            state = self._states.get(self.key(fingerprint, experiment_id))
            return None if state is None else state.payload()


EXPERIMENTS = Experiments()


def _submit_run(run: RunRow, client: NimbusClient) -> None:
    """POST /api/execute once; marks the run failed on an error or on a
    malformed 200 (no executionId — failing only THIS run, not the
    experiment). Queue-full is never an HTTP error: POST answers 200
    immediately and the backend's concurrency gate reports "Execution queue
    full" later via the polled summary — _drive resubmits there."""
    body: dict[str, Any] = {
        "train": run.train_graph,
        "layout": synth_layout(run.train_graph),
        "name": run.name,
    }
    run.submit_attempts += 1
    try:
        payload = client.post("/api/execute", json=body)
    except McpToolError as err:
        run.status = "failed"
        run.error = str(err)
        return
    exec_id = payload.get("executionId")
    if not isinstance(exec_id, str) or not exec_id:
        run.status = "failed"
        run.error = "backend accepted the run but returned no executionId"
        return
    run.execution_id = exec_id
    run.status = "running"


def _fetch_metrics(exec_id: str, client: NimbusClient) -> dict[str, Any] | None:
    """Trimmed metrics for a completed run, or None when the result fetch
    fails (the run is then treated as failed, not completed-without-metrics)."""
    try:
        payload = client.get(f"/api/result/{exec_id}")
    except SetupRequired:
        # A hosted token that died mid-experiment is a setup problem, not a
        # bad result: let the guidance propagate instead of mislabeling the
        # run "completed but result fetch failed".
        raise
    except McpToolError:
        return None
    metrics = (payload.get("result") or {}).get("metrics") or {}
    return {k: metrics[k] for k in _METRIC_KEYS if metrics.get(k) is not None}


def _poll_summary(exec_id: str, client: NimbusClient) -> dict[str, Any]:
    """GET the execution summary, retrying transient failures (a 5xx or a
    momentary connection blip, both surface as McpToolError) up to
    MAX_POLL_ATTEMPTS total attempts with POLL_RETRY_BACKOFF_SEC between them;
    after that the error propagates to the worker's catch-all. Non-McpToolError
    exceptions are never retried, and SetupRequired (token expired mid-session)
    propagates immediately — retrying login guidance is pointless."""
    attempt = 0
    while True:
        attempt += 1
        try:
            return client.get(f"/api/executions/{exec_id}/summary")
        except SetupRequired:
            raise
        except McpToolError:
            if attempt >= MAX_POLL_ATTEMPTS:
                raise
            time.sleep(POLL_RETRY_BACKOFF_SEC)


def _drive(state: ExperimentState, client: NimbusClient) -> None:
    """Paced submission loop: keep <= max_in_flight executions running, poll
    summaries every POLL_INTERVAL_SEC, promote terminal runs, submit the next."""
    pending = list(state.runs)
    in_flight: dict[str, RunRow] = {}
    while pending or in_flight:
        while pending and len(in_flight) < state.max_in_flight:
            run = pending.pop(0)
            _submit_run(run, client)
            if run.execution_id is not None:
                in_flight[run.execution_id] = run
        if not in_flight:
            break  # every submission failed; nothing to poll
        time.sleep(POLL_INTERVAL_SEC)
        for exec_id in list(in_flight):
            summary = _poll_summary(exec_id, client).get("summary") or {}
            status = summary.get("status")
            run = in_flight[exec_id]
            if status == "completed":
                metrics = _fetch_metrics(exec_id, client)
                if metrics is None:
                    run.status = "failed"
                    run.error = f"run completed but result fetch failed for {exec_id}"
                else:
                    run.metrics = metrics
                    run.status = "completed"
                del in_flight[exec_id]
            elif status in _TERMINAL:  # failed | cancelled
                error = summary.get("errorMessage") or f"terminal status: {status}"
                if _QUEUE_FULL_MARKER in error and run.submit_attempts < MAX_SUBMIT_ATTEMPTS:
                    # The concurrency gate rejected the run via the summary
                    # (status failed, errorMessage queue-full) — back off and
                    # resubmit the same run as a new execution.
                    del in_flight[exec_id]
                    time.sleep(QUEUE_FULL_BACKOFF_SEC)
                    _submit_run(run, client)
                    if run.execution_id is not None and run.execution_id != exec_id:
                        in_flight[run.execution_id] = run
                    continue
                run.status = "failed"
                run.error = error
                del in_flight[exec_id]


def _compute_aggregates(runs: list[RunRow]) -> dict[str, Any]:
    """{metric: {mean, std, best: {name, value}}} over completed runs only.
    std is the population standard deviation; None below 2 values."""
    completed = [run for run in runs if run.status == "completed" and run.metrics]
    aggregates: dict[str, Any] = {}
    for key in _AGGREGATE_METRICS:
        pairs: list[tuple[str, Any]] = []
        for run in completed:
            value = run.metrics.get(key) if run.metrics else None
            if value is not None:
                pairs.append((run.name, value))
        if not pairs:
            continue
        values = [value for _, value in pairs]
        best_name, best_value = max(pairs, key=lambda pair: pair[1])
        aggregates[key] = {
            "mean": fmean(values),
            "std": pstdev(values) if len(values) >= 2 else None,
            "best": {"name": best_name, "value": best_value},
        }
    return aggregates


def _experiment_worker(
    state: ExperimentState,
    binding: AbstractContextManager[NimbusClient],
) -> None:
    """Background thread body: drive the experiment, then finalize status and
    aggregates. The binding owns the worker's client lifetime — the hosted
    wrapper yields a per-token client (closed here on exit; the worker has no
    request context to resolve headers in), a plain client yields the shared
    singleton (never closed). Any unexpected error (e.g. backend gone
    mid-run) fails the still-open runs instead of leaving the experiment
    'running' forever."""
    with binding as client:
        try:
            _drive(state, client)
        except Exception as err:
            with EXPERIMENTS.lock:
                for run in state.runs:
                    if run.status not in ("completed", "failed"):
                        run.status = "failed"
                        run.error = f"experiment aborted: {err}"
        finally:
            with EXPERIMENTS.lock:
                state.aggregates = _compute_aggregates(state.runs)
                state.status = (
                    "failed" if all(run.status == "failed" for run in state.runs) else "completed"
                )


def register(mcp: FastMCP, client: NimbusClient) -> None:
    @mcp.tool(name="experiment.run", annotations=MUTATING)
    def run_experiment(runs: list[dict[str, Any]], max_concurrent: int = 2) -> dict[str, Any]:
        """Run 1-25 pipelines as ONE paced experiment (NON-BLOCKING). Returns an
        experimentId immediately; a background thread submits at most 2 runs at
        a time (min(max_concurrent, 2)), retries queue-full up to 3 times per
        run, and polls each execution to completion. Poll experiment.get() for
        per-run status and, once finished, aggregated metrics.

        Args:
            runs: 1-25 entries, each {name: str, train_graph: {nodes, connections}}
                (same graph shape as execution.run's train_graph).
            max_concurrent: Parallel submissions cap, clamped to 1-2 (default 2).
        """
        # Preflight BEFORE registering state or spawning the worker thread:
        # in setup mode the worker's catch-all would swallow SetupRequired
        # into per-run errors and the tool would answer a misleading
        # {status: "running"} instead of the setup guidance dict.
        client.ensure_ready()
        if not runs:
            raise McpToolError("experiment.run needs at least 1 run (got 0).")
        if len(runs) > MAX_RUNS:
            raise McpToolError(
                f"experiment.run accepts at most {MAX_RUNS} runs (got {len(runs)}). "
                "Split the sweep into several experiments."
            )
        prepared: list[RunRow] = []
        for index, item in enumerate(runs):
            if not isinstance(item, dict) or not isinstance(item.get("train_graph"), dict):
                raise McpToolError(
                    f"Run {index} is invalid: every run needs a 'train_graph' dict "
                    "(same shape as execution.run's train_graph)."
                )
            prepared.append(
                RunRow(
                    name=str(item.get("name") or f"run-{index + 1}"),
                    train_graph=item["train_graph"],
                )
            )
        experiment_id = uuid.uuid4().hex
        compute_origin: dict[str, Any] | None = None
        try:
            profile = client.get("/api/me/profile")
            origin = profile.get("computeOrigin") if isinstance(profile, dict) else None
            if isinstance(origin, dict):
                compute_origin = origin
        except (McpToolError, SetupRequired):
            # Best-effort provenance stamp; never block experiment.start on profile blips.
            pass
        state = ExperimentState(
            experiment_id=experiment_id,
            runs=prepared,
            max_in_flight=max(1, min(max_concurrent, MAX_IN_FLIGHT)),
            compute_origin=compute_origin,
        )
        # Scope the registry entry to the calling credential BEFORE
        # registering/spawning: the fingerprint must be captured here, inside
        # the request (the worker thread has no MCP request context to resolve
        # a per-request token in — it only mutates the state object, never the
        # registry key). The id returned to the caller stays plain.
        fingerprint = client.credential_fingerprint()
        EXPERIMENTS.add(state, fingerprint)
        # Bind BEFORE spawning: the worker thread has no MCP request context
        # (fastmcp's header lookup answers {} there), so a request-scoped
        # client — the hosted gateway — cannot resolve its per-request token
        # mid-experiment. bound_client() runs here, inside the request.
        worker_binding = client.bound_client()
        threading.Thread(
            target=_experiment_worker,
            args=(state, worker_binding),
            name=f"nimbus-experiment-{experiment_id[:8]}",
            daemon=True,
        ).start()
        return {
            "experimentId": experiment_id,
            "status": "running",
            "runs": [{"name": run.name, "executionId": None} for run in prepared],
            "pollHint": "Runs submit in the background. Call experiment.get(experiment_id) "
            "until status is completed or failed.",
        }

    @mcp.tool(name="experiment.get", annotations=READ_ONLY)
    def get_experiment(experiment_id: str) -> dict[str, Any]:
        """Experiment snapshot: status (running/completed/failed), per-run rows
        ({name, executionId, status, error?, metrics?}) and, once finished,
        aggregates {metric: {mean, std, best: {name, value}}} over completed
        runs only (std = population; None below 2 values).

        Args:
            experiment_id: The experiment to inspect (from experiment.run).
        """
        # Symmetry with experiment.run: in setup mode no experiment can exist
        # (its preflight refuses), so answer with guidance rather than the
        # confusing "Unknown experiment".
        client.ensure_ready()
        exp_id = safe_segment(experiment_id, label="experiment id")
        # The caller's own key only: another credential's experiment with the
        # same id is indistinguishable from a foreign-process one.
        snapshot = EXPERIMENTS.snapshot(client.credential_fingerprint(), exp_id)
        if snapshot is None:
            raise McpToolError(
                f"Unknown experiment '{exp_id}'. It was run in another MCP server "
                "process, or the id is wrong — experiment state is process-local."
            )
        return snapshot
