"""Hosted gateway: HeaderCredentialClient per-request credential resolution."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

import httpx
import pytest

from nimbus_mcp import hosted
from nimbus_mcp.client import NimbusClient
from nimbus_mcp.config import McpConfig
from nimbus_mcp.hosted import HeaderCredentialClient, hosted_setup_guidance
from nimbus_mcp.setup_mode import SetupRequired, token_rejected_guidance


class FakeClient:
    """Records calls; optionally raises per-call."""

    def __init__(self, config: McpConfig) -> None:
        self.config = config
        self.calls: list[tuple[str, tuple[Any, ...]]] = []
        self.raise_on_get: Exception | None = None

    def get(self, path, params=None):
        self.calls.append(("get", (path, params)))
        if self.raise_on_get is not None:
            raise self.raise_on_get
        return {"ok": True, "token": self.config.nimbus_token}

    def ensure_ready(self):
        self.calls.append(("ensure_ready", ()))
        if self.raise_on_get is not None:
            raise self.raise_on_get

    def close(self):
        self.calls.append(("close", ()))


def _config(token: str = "") -> McpConfig:
    return McpConfig(
        api_url="https://example.test",
        mcp_key="",
        export_dir=Path("/tmp/exports"),
        nimbus_token=token,
    )


def _client(
    headers: dict[str, str], config: McpConfig | None = None
) -> tuple[HeaderCredentialClient, list[FakeClient]]:
    made: list[FakeClient] = []

    def factory(cfg: McpConfig) -> FakeClient:
        client = FakeClient(cfg)
        made.append(client)
        return client

    proxy = HeaderCredentialClient(
        config if config is not None else _config(),
        client_factory=factory,  # type: ignore[arg-type]
        headers_getter=lambda: headers,
    )
    return proxy, made


def test_headerless_call_returns_hosted_guidance() -> None:
    proxy, made = _client({})
    with pytest.raises(SetupRequired) as err:
        proxy.get("/api/anything")
    assert made == []  # nothing built without a credential
    guidance = err.value.guidance
    assert guidance["setupRequired"] is True
    assert "X-Nimbus-Token" in guidance["message"]
    assert any("uvx nimbus-mcp" in o["action"] for o in guidance["options"])


def test_x_nimbus_token_header_builds_token_client() -> None:
    proxy, made = _client({"x-nimbus-token": "nimb_test_token"})
    result = proxy.get("/api/me/profile")
    assert result == {"ok": True, "token": "nimb_test_token"}
    assert len(made) == 1
    # The per-request client is pure Bearer mode: no local key, header source.
    assert made[0].config.nimbus_token == "nimb_test_token"
    assert made[0].config.mcp_key == ""
    assert made[0].config.credential_meta == {"source": "header"}
    # Base config survives for tool-side reads (export_dir etc.).
    assert proxy.config is not None


def test_authorization_bearer_form_accepted() -> None:
    proxy, made = _client({"authorization": "Bearer nimb_bearer_form"})
    assert proxy.get("/x") == {"ok": True, "token": "nimb_bearer_form"}
    assert len(made) == 1


# ── X-Nimbus-Token may carry an Authorization-style Bearer prefix ───────────
# MCP clients that template one header shape into both fields send
# "X-Nimbus-Token: Bearer nimb_…"; without normalization the gateway would
# forward Authorization: Bearer Bearer nimb_… and the auth layer would reject
# every call from such a client.


def test_x_nimbus_token_bearer_prefix_is_stripped() -> None:
    proxy, made = _client({"x-nimbus-token": "Bearer nimb_x"})
    assert proxy.get("/x") == {"ok": True, "token": "nimb_x"}
    assert made[0].config.nimbus_token == "nimb_x"


def test_x_nimbus_token_bearer_prefix_case_insensitive() -> None:
    proxy, _ = _client({"x-nimbus-token": "bearer nimb_lower"})
    assert proxy._current_token() == "nimb_lower"


def test_x_nimbus_token_bearer_prefix_not_double_prefixed_on_wire() -> None:
    """End-to-end through the real NimbusClient: the Authorization header the
    backend receives is exactly `Bearer nimb_x` — never `Bearer Bearer nimb_x`."""
    seen: list[str | None] = []

    def handler(req: httpx.Request) -> httpx.Response:
        seen.append(req.headers.get("authorization"))
        return httpx.Response(200, json={"ok": True})

    proxy = HeaderCredentialClient(
        _config(),
        client_factory=lambda cfg: NimbusClient(cfg, transport=httpx.MockTransport(handler)),
        headers_getter=lambda: {"x-nimbus-token": "Bearer nimb_x"},
    )
    assert proxy.get("/api/me/profile") == {"ok": True}
    assert seen == ["Bearer nimb_x"]


def test_post_forwards_allow_422_to_the_token_client() -> None:
    """Hosted protocol.validate passes allow_422. The wrapper must forward it
    so a 422 verdict is returned instead of TypeError (NIMBUS-MCP-3)."""

    def handler(req: httpx.Request) -> httpx.Response:
        assert req.method == "POST"
        assert req.url.path == "/api/protocols/validate"
        return httpx.Response(422, json={"valid": False, "errors": [{"msg": "bad"}]})

    proxy = HeaderCredentialClient(
        _config(),
        client_factory=lambda cfg: NimbusClient(cfg, transport=httpx.MockTransport(handler)),
        headers_getter=lambda: {"x-nimbus-token": "nimb_validate"},
    )
    assert proxy.post("/api/protocols/validate", json={"spec": {}}, allow_422=True) == {
        "valid": False,
        "errors": [{"msg": "bad"}],
    }


def test_x_nimbus_token_bearer_only_value_is_no_credential() -> None:
    """`Bearer ` with nothing after it is not a credential — headerless
    guidance applies, and the env fallback (if any) wins."""
    proxy, made = _client({"x-nimbus-token": "Bearer "}, config=_config(token="nimb_env"))
    assert proxy.get("/x") == {"ok": True, "token": "nimb_env"}


# ── credential_report: truthful per-request identity for whoami ────────────


def test_credential_report_header_token_masked() -> None:
    proxy, _ = _client({"x-nimbus-token": "nimb_gateway_token"})
    assert proxy.credential_report() == {"source": "header", "token": "nimb_gateway…"}


def test_credential_report_bearer_header_also_source_header() -> None:
    proxy, _ = _client({"authorization": "Bearer nimb_auth_form"})
    assert proxy.credential_report() == {"source": "header", "token": "nimb_auth_fo…"}


def test_credential_report_env_fallback_source_and_mask() -> None:
    """Headerless call on a gateway started with NIMBUS_TOKEN: the fallback
    supplied the credential, so the report says so (not "header")."""
    proxy, _ = _client({}, config=_config(token="nimb_env_fallback"))
    assert proxy.credential_report() == {"source": "env", "token": "nimb_env_fal…"}


def test_credential_report_no_token_reports_none() -> None:
    proxy, _ = _client({})
    assert proxy.credential_report() == {"source": "env", "token": None}


def test_token_clients_are_cached_per_token() -> None:
    headers: dict[str, str] = {}
    made: list[FakeClient] = []

    def factory(cfg: McpConfig) -> FakeClient:
        client = FakeClient(cfg)
        made.append(client)
        return client

    proxy = HeaderCredentialClient(
        _config(), client_factory=factory, headers_getter=lambda: headers
    )
    headers["x-nimbus-token"] = "nimb_a"
    proxy.get("/1")
    proxy.get("/2")
    headers["x-nimbus-token"] = "nimb_b"
    proxy.get("/3")
    headers["x-nimbus-token"] = "nimb_a"
    proxy.get("/4")
    assert len(made) == 2  # one client per distinct token


def test_startup_env_token_is_fallback_for_headerless_calls() -> None:
    proxy, made = _client({}, config=_config(token="nimb_env_fallback"))
    assert proxy.get("/x") == {"ok": True, "token": "nimb_env_fallback"}
    # An explicit header still wins over the process credential.
    headers = {"x-nimbus-token": "nimb_header_wins"}
    made[0].config = replace(made[0].config, nimbus_token="nimb_header_wins")
    proxy2, _ = _client(headers, config=_config(token="nimb_env_fallback"))
    # (proxy2 builds its own; just assert resolution picks the header)
    assert proxy2._current_token() == "nimb_header_wins"


def test_rejected_token_translates_to_hosted_guidance() -> None:
    made: list[FakeClient] = []

    def factory(cfg: McpConfig) -> FakeClient:
        client = FakeClient(cfg)
        client.raise_on_get = SetupRequired(token_rejected_guidance("nimb_expired", 401))
        made.append(client)
        return client

    proxy = HeaderCredentialClient(
        _config(),
        client_factory=factory,  # type: ignore[arg-type]
        headers_getter=lambda: {"x-nimbus-token": "nimb_expired"},
    )
    with pytest.raises(SetupRequired) as err:
        proxy.get("/api/me/profile")
    guidance = err.value.guidance
    # B4: a token WAS sent — say it was rejected and to re-mint it, never
    # the "add the X-Nimbus-Token header" guidance for headerless calls.
    assert "rejected" in guidance["message"]
    assert "received your Nimbus API token" in guidance["message"]
    assert "gateway" in guidance["message"]
    assert "add the" not in guidance["options"][0]["action"]
    assert "fresh token" in guidance["options"][0]["action"]
    assert "X-Nimbus-Token" in guidance["options"][0]["detail"]
    assert guidance["tokenRejected"] is True
    # Situation extras survive the translation (rejected-with-days-left case
    # carries daysLeft; the undecodable case carries neither — both fine).
    assert guidance.get("daysLeft") is None or isinstance(guidance["daysLeft"], int)


def test_ensure_ready_enforces_header() -> None:
    proxy, _ = _client({})
    with pytest.raises(SetupRequired):
        proxy.ensure_ready()
    proxy2, _ = _client({"x-nimbus-token": "nimb_ok"})
    proxy2.ensure_ready()  # no raise


def test_gateway_credential_check_translates_rejection_and_caches() -> None:
    """B5 on the gateway: a sent-but-rejected token fails the experiment.run
    credential check with the rejected-token guidance; ensure_ready itself
    stays a cheap header check (no backend call)."""
    from nimbus_mcp.access import clear_tier_cache, verify_hosted_credential

    clear_tier_cache()
    made: list[FakeClient] = []

    def factory(cfg: McpConfig) -> FakeClient:
        client = FakeClient(cfg)
        client.raise_on_get = SetupRequired(token_rejected_guidance("nimb_bad", 401))
        made.append(client)
        return client

    proxy = HeaderCredentialClient(
        _config(),
        client_factory=factory,  # type: ignore[arg-type]
        headers_getter=lambda: {"authorization": "Bearer nimb_bad"},
    )
    proxy.ensure_ready()  # header present: no raise, no backend call
    assert all(not c.calls for c in made)
    with pytest.raises(SetupRequired) as err:
        verify_hosted_credential(proxy)
    assert "rejected" in err.value.guidance["message"]
    assert "add the" not in err.value.guidance["options"][0]["action"]

    clear_tier_cache()
    ok_made: list[FakeClient] = []

    def ok_factory(cfg: McpConfig) -> FakeClient:
        client = FakeClient(cfg)
        client.get = lambda path, params=None: (  # type: ignore[method-assign]
            client.calls.append(("get", (path, params))) or {"capabilities": {"isPro": True}}
        )
        ok_made.append(client)
        return client

    ok = HeaderCredentialClient(
        _config(),
        client_factory=ok_factory,  # type: ignore[arg-type]
        headers_getter=lambda: {"x-nimbus-token": "nimb_good"},
    )
    verify_hosted_credential(ok)
    verify_hosted_credential(ok)  # cached per credential: one profile call
    assert sum(1 for c in ok_made for call in c.calls if call[0] == "get") == 1
    clear_tier_cache()


def test_headerless_call_still_gets_add_header_guidance() -> None:
    proxy, _ = _client({})
    with pytest.raises(SetupRequired) as err:
        proxy.get("/x")
    assert "X-Nimbus-Token" in err.value.guidance["options"][0]["action"]


def test_client_cache_is_bounded() -> None:
    headers: dict[str, str] = {}
    proxy, made = _client(headers)
    proxy._max_clients = 3
    for i in range(5):
        headers["x-nimbus-token"] = f"nimb_{i}"
        proxy.get(f"/{i}")
    # cap 3 → the 4th build clears the map first: at most 3 alive at a time,
    # 5 tokens total → 5 builds but never more than 3 retained.
    assert len(made) == 5
    assert len(proxy._clients) <= 3


def test_hosted_guidance_shape_matches_spec() -> None:
    guidance = hosted_setup_guidance(daysExpired=2)
    assert guidance["ok"] is False
    assert guidance["setupRequired"] is True
    assert guidance["daysExpired"] == 2
    assert isinstance(guidance["options"], list) and guidance["options"]


# ── bound_client: workers outlive the request context ──────────────────────
# A background worker thread (experiment.run) has no MCP request context:
# get_http_headers() returns {} there, so per-request token resolution cannot
# run. bound_client() yields a token-bound client the worker owns for its
# lifetime — the header getter is never consulted inside the worker.


def test_bound_client_works_after_request_context_gone() -> None:
    """The bound client keeps working once the header getter goes empty (the
    worker-thread situation) and is closed when the context exits."""
    headers: dict[str, str] = {"x-nimbus-token": "nimb_bound"}
    proxy, made = _client(headers)

    with proxy.bound_client() as bound:
        headers.clear()  # request context gone — proxy resolution now fails
        with pytest.raises(SetupRequired):
            proxy.get("/api/noworker")  # sanity: the proxy itself is stranded
        assert bound.get("/api/worker") == {"ok": True, "token": "nimb_bound"}
        assert made, "bound client was built"
    # Worker-owned: closed on context exit (FakeClient records the call).
    assert any(call == ("close", ()) for client in made for call in client.calls)


def test_bound_client_headerless_raises_guidance() -> None:
    proxy, made = _client({})
    with pytest.raises(SetupRequired) as err:
        proxy.bound_client()
    assert made == []
    assert err.value.guidance["setupRequired"] is True


def test_bound_client_discard_closes_without_the_context_running() -> None:
    """A watch that goes away WITHOUT the with-block ever running (explicit
    stream.stop, replacement registration) must still release the fresh
    per-token client: bound_client() exposes discard() for exactly that."""
    headers: dict[str, str] = {"x-nimbus-token": "nimb_disc"}
    proxy, made = _client(headers)

    binding = proxy.bound_client()
    binding.discard()  # never entered — closed by the discard alone
    assert any(call == ("close", ()) for client in made for call in client.calls)
    binding.discard()  # idempotent


# ── eviction must not close clients other threads are using ────────────────


def test_eviction_retires_before_closing() -> None:
    """At the client cap, eviction drops cache references but closes only the
    set retired by the PREVIOUS eviction — a mid-request client from the
    current set survives; the retired set has a full cycle to drain."""
    headers: dict[str, str] = {}
    made: list[FakeClient] = []

    def factory(cfg: McpConfig) -> FakeClient:
        client = FakeClient(cfg)
        made.append(client)
        return client

    proxy = HeaderCredentialClient(
        _config(), client_factory=factory, headers_getter=lambda: headers, max_clients=2
    )
    headers["x-nimbus-token"] = "nimb_a"
    proxy.get("/1")
    headers["x-nimbus-token"] = "nimb_b"
    proxy.get("/2")
    a, b = made
    assert not a.calls or a.calls[-1] != ("close", ())

    headers["x-nimbus-token"] = "nimb_c"  # cap (2) reached → evict a, b
    proxy.get("/3")
    assert ("close", ()) not in a.calls and ("close", ()) not in b.calls  # retired, alive

    headers["x-nimbus-token"] = "nimb_d"  # cache {c} only — no eviction yet
    proxy.get("/4")
    assert ("close", ()) not in a.calls and ("close", ()) not in b.calls

    headers["x-nimbus-token"] = "nimb_e"  # cap reached again → close the retired a, b
    proxy.get("/5")
    assert ("close", ()) in a.calls and ("close", ()) in b.calls
    # Freshly cached clients from the previous eviction stay open.
    c = made[2]
    assert ("close", ()) not in c.calls


# ── the default header getter must expose `authorization` ──────────────────
# fastmcp's get_http_headers strips credential headers (authorization, cookie)
# by default; a plain default getter makes the Bearer fallback below
# unreachable on the real gateway. Pin the default against real fastmcp.


def test_default_headers_getter_includes_authorization() -> None:
    from fastmcp.server import dependencies as dep

    var = getattr(dep, "_current_http_request", None)
    if var is None or not hasattr(var, "set"):
        pytest.skip("fastmcp request ContextVar moved — re-pin this test")
    from starlette.requests import Request

    scope = {
        "type": "http",
        "method": "POST",
        "path": "/mcp",
        "headers": [(b"authorization", b"Bearer nimb_live")],
        "query_string": b"",
        "scheme": "http",
    }
    token = var.set(Request(scope))
    try:
        # fastmcp's documented default: credential headers stripped …
        assert dep.get_http_headers().get("authorization") is None
        # … so the gateway's default getter must request them explicitly.
        headers = hosted._default_headers_getter()
    finally:
        var.reset(token)
    assert headers.get("authorization") == "Bearer nimb_live"


def test_default_headers_getter_falls_back_when_include_missing(monkeypatch) -> None:
    """fastmcp <2.10 has no `include` kwarg: the getter degrades to the plain
    call (X-Nimbus-Token resolution unaffected) instead of crashing."""
    calls: list[dict[str, object]] = []

    def fake(**kwargs: object) -> dict[str, str]:
        calls.append(kwargs)
        if "include" in kwargs:
            raise TypeError("unexpected keyword argument 'include'")
        return {"x-nimbus-token": "nimb_ok"}

    monkeypatch.setattr(hosted, "get_http_headers", fake)
    assert hosted._default_headers_getter() == {"x-nimbus-token": "nimb_ok"}
    assert calls == [{"include": {"authorization"}}, {}]  # retried plain
