"""Whoami tool: the authenticated identity, plan, quota, and token countdown."""

from __future__ import annotations

import math
import time
from datetime import datetime, timezone
from typing import Any

from fastmcp import FastMCP

from ..access import MODE_ANONYMOUS, client_mode
from ..client import NimbusClient
from ..credentials import decode_token_claims, token_access_summary
from ._annotations import READ_ONLY


def _token_info(client: NimbusClient) -> dict[str, Any] | None:
    """Display info for the active hosted token — LOCAL decode only.

    ``name`` comes from the credential store metadata (written by
    ``nimbus-mcp login``; the JWT itself carries no name claim), the expiry
    from the token's own ``exp`` via :func:`decode_token_claims` (no
    verification, no extra endpoint). The raw secret never appears. In
    local-key modes there is no token: ``None``.
    """
    token = client.config.nimbus_token
    if not token:
        return None
    info: dict[str, Any] = {}
    name = client.config.credential_meta.get("name")
    if isinstance(name, str) and name:
        info["name"] = name
    claims = decode_token_claims(token)
    info.update(token_access_summary(claims))
    exp = claims.get("exp")
    if isinstance(exp, (int, float)) and not isinstance(exp, bool):
        info["expiresAt"] = datetime.fromtimestamp(exp, timezone.utc).isoformat()
        info["daysLeft"] = max(0, math.ceil((exp - time.time()) / 86400))
    return info or None


def _real_email(value: object) -> str | None:
    """Drop the backend's ``<user_id>@clerk.local`` placeholder (E2E 2026-10-21)."""
    if not isinstance(value, str) or not value or value.endswith("@clerk.local"):
        return None
    return value


def register(mcp: FastMCP, client: NimbusClient) -> None:
    @mcp.tool(name="account.whoami", annotations=READ_ONLY)
    def whoami() -> dict[str, Any]:
        """Who you are authenticated as: account email, plan (isPro / pioneer),
        this month's free-run quota, and — with a hosted token — the token name
        and days until it expires. Call this first when setup guidance appears
        or to check which credential a session uses. In anonymous Local Free
        mode there is no account: the response says so (mode/tier) instead of
        demanding a login."""
        if client_mode(client) == MODE_ANONYMOUS:
            return {
                "authenticated": False,
                # Same name the access model and telemetry events use
                # (access.MODE_ANONYMOUS); the tier says it is Local Free.
                "mode": "anonymous",
                "tier": "local-free",
                "userId": None,
                "email": None,
                "plan": {"isPro": False, "pioneerAccess": False},
                "loginRequired": False,
                "cloudFeaturesRequiringLogin": [
                    "leaderboard.submit (identity)",
                    "verified / cross-machine experiment history",
                    "hosted compute and campaigns",
                    "cloud sync / backup",
                    "collaboration",
                ],
                "note": (
                    "Local Free: templates, your own data, local execution, "
                    "plots/stats, BIDS export and local-only storage work "
                    "with no Nimbus Studio login."
                ),
            }
        profile = client.get("/api/me/profile")
        caps = profile.get("capabilities") or {}
        report = client.credential_report()
        token_info = _token_info(client)
        if report["source"] == "header":
            # Gateway per-request credential: no store metadata exists for a
            # header token, so the masked prefix from the report is the only
            # truthful identifier of WHICH token carried this call. Local
            # credential modes never gain token material here — name/expiry
            # identify them, and the raw secret is never printed.
            token_info = {"masked": report["token"]}
            claims_fn = getattr(client, "current_token_claims", None)
            claims = claims_fn() if callable(claims_fn) else {}
            token_info.update(token_access_summary(claims))
            exp = claims.get("exp")
            if isinstance(exp, (int, float)) and not isinstance(exp, bool):
                token_info["expiresAt"] = datetime.fromtimestamp(exp, timezone.utc).isoformat()
                token_info["daysLeft"] = max(0, math.ceil((exp - time.time()) / 86400))
        return {
            "userId": profile.get("userId"),
            "email": _real_email(profile.get("email")),
            "plan": {
                "isPro": bool(caps.get("isPro")),
                "pioneerAccess": bool(caps.get("hasPioneerAccess")),
            },
            "freeRuns": {
                "monthlyLimit": caps.get("freeTrainingRunsMonthlyLimit"),
                "remaining": caps.get("freeTrainingRunsRemaining"),
            },
            "computeOrigin": profile.get("computeOrigin"),
            "token": token_info,
            "source": report["source"],
        }
